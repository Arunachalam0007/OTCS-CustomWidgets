// Defines localizable strings in the default language (English)

define({
  helloMessage: 'Hello {0} {1}!',
  waitMessage: 'One moment, please...'
});
